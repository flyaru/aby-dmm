/** Air Arabia DMM speech: direct Edge Neural synthesis with bounded public fallback. */
const VOICES = new Set(['en-US-GuyNeural','ar-AE-HamdanNeural','ar-SA-HamedNeural','ur-PK-AsadNeural']);
const HEADERS = {'Access-Control-Allow-Origin':'*','Access-Control-Allow-Headers':'Content-Type','Access-Control-Allow-Methods':'POST, OPTIONS'};
const json = (statusCode, value) => ({statusCode,headers:{...HEADERS,'Content-Type':'application/json','Cache-Control':'no-store'},body:JSON.stringify(value)});
const wait = ms => new Promise(r=>setTimeout(r,ms));
function audioResponse(buffer){
  if (!Buffer.isBuffer(buffer) || buffer.length < 600) throw Error('No playable audio was produced');
  const mp3 = (buffer[0]===0x49&&buffer[1]===0x44&&buffer[2]===0x33) || (buffer[0]===0xff&&(buffer[1]&0xe0)===0xe0);
  if(!mp3) throw Error('Response was not MP3 audio');
  return {statusCode:200,headers:{...HEADERS,'Content-Type':'audio/mpeg','Cache-Control':'public, max-age=1800'},body:buffer.toString('base64'),isBase64Encoded:true};
}
async function directSynthesis(text, voice, rate){
  // Build-time dependency, bundled by Netlify's esbuild; no API key required.
  const { Communicate } = require('@travisvn/edge-tts');
  const generator = new Communicate(text, {voice,rate,connectionTimeout:10000});
  const chunks=[];let size=0;
  for await(const chunk of generator.stream()){
    if(chunk.type==='audio' && chunk.data){const b=Buffer.from(chunk.data);size+=b.length;if(size>4_000_000)throw Error('Audio exceeds size limit');chunks.push(b);}
  }
  return audioResponse(Buffer.concat(chunks));
}
async function fetchTimed(url,ms){
  const ctrl=new AbortController(); const timer=setTimeout(()=>ctrl.abort(),ms);
  try {return await fetch(url,{signal:ctrl.signal,headers:{'Accept':'audio/mpeg'}});} finally{clearTimeout(timer);}
}
async function publicFallback(text,voice){
  const url='https://edge-tts.vercel.app/api/tts?'+new URLSearchParams({text,voice});
  const response=await fetchTimed(url,8500);
  if(!response.ok)throw Error('Public fallback HTTP '+response.status);
  if(!String(response.headers.get('content-type')||'').includes('audio'))throw Error('Public fallback returned non-audio response');
  return audioResponse(Buffer.from(await response.arrayBuffer()));
}
exports.handler=async event=>{
  if(event.httpMethod==='OPTIONS')return {statusCode:204,headers:HEADERS,body:''};
  if(event.httpMethod==='GET')return json(200,{status:'function_deployed',name:'tts',version:'1.2.1',voiceProvider:'Edge Neural (upstream availability not verified)'});
  if(event.httpMethod!=='POST')return json(405,{error:'POST required'});
  let input;try{input=JSON.parse(event.body||'{}')}catch{return json(400,{error:'Invalid JSON'});}
  const text=String(input.text||'').trim();
  if(!text||text.length>1800)return json(400,{error:'Text must be between 1 and 1800 characters'});
  const voice=VOICES.has(input.voice)?input.voice:'en-US-GuyNeural';
  const rate=/^[+-]?\d{1,2}%$/.test(String(input.rate||''))?String(input.rate):'+0%';
  const errors=[];
  for(let attempt=0;attempt<2;attempt++){
    try {return await directSynthesis(text,voice,rate);}catch(e){errors.push('Direct Neural TTS: '+String(e.message||e).slice(0,140)); if(attempt===0)await wait(500);}
  }
  try{return await publicFallback(text,voice);}catch(e){errors.push(String(e.message||e));}
  console.error('TTS sources failed:', errors.join(' | '));
  return json(503,{error:'Neural voice service is unavailable. No audio generated. Try again later or play an already generated announcement.',code:'TTS_UPSTREAM_UNAVAILABLE',details:errors});
};
